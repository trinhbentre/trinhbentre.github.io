import { useState, useRef, useCallback } from 'react'

export function useCopyToClipboard(timeoutMs = 2000) {
  const [copied, setCopied] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const copy = useCallback(
    (text: string) => {
      navigator.clipboard.writeText(text).then(() => {
        setCopied(true)
        if (timerRef.current) clearTimeout(timerRef.current)
        timerRef.current = setTimeout(() => setCopied(false), timeoutMs)
      }).catch(() => {
        // Clipboard unavailable — silently ignore
      })
    },
    [timeoutMs],
  )

  return { copied, copy }
}
