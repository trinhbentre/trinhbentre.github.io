import { useState, useEffect, useRef } from 'react'

export function useStorage<T>(key: string, defaultValue: T): [T, (val: T) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(key)
      return stored !== null ? (JSON.parse(stored) as T) : defaultValue
    } catch {
      return defaultValue
    }
  })

  const mounted = useRef(false)
  useEffect(() => {
    if (!mounted.current) {
      mounted.current = true
      return
    }
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch {
      // localStorage unavailable — silently ignore
    }
  }, [key, value])

  return [value, setValue]
}
