import { useEffect, useCallback } from 'react'

type KeyCombo = {
  /** Key value from KeyboardEvent.key */
  key: string
  /** Require Ctrl or Cmd (metaKey) */
  ctrl?: boolean
  /** Require Shift */
  shift?: boolean
  /** Require Alt / Option */
  alt?: boolean
}

export function useKeyboardShortcut(combo: KeyCombo, handler: () => void) {
  const stableHandler = useCallback(handler, [handler])

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const ctrl = e.ctrlKey || e.metaKey
      if (!!combo.ctrl !== ctrl) return
      if (!!combo.shift !== e.shiftKey) return
      if (!!combo.alt !== e.altKey) return
      if (e.key.toLowerCase() !== combo.key.toLowerCase()) return
      e.preventDefault()
      stableHandler()
    }

    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [combo.key, combo.ctrl, combo.shift, combo.alt, stableHandler])
}
