import { HomeIcon } from './icons/HomeIcon'

interface AppHeaderProps {
  toolName: string
  toolIcon?: React.ReactNode
  actions?: React.ReactNode
  homepageUrl?: string
}

export function AppHeader({
  toolName,
  toolIcon,
  actions,
  homepageUrl = 'https://trinhbentre.github.io/',
}: AppHeaderProps) {
  return (
    <header className="h-11 flex items-center px-4 gap-3 border-b border-surface-700 bg-surface-800 shadow-md shrink-0">
      <a
        href={homepageUrl}
        className="flex-shrink-0 text-text-muted hover:text-accent transition-colors"
        title="Back to homepage"
        aria-label="Back to homepage"
      >
        <HomeIcon className="w-4 h-4" />
      </a>

      <div className="w-px h-5 bg-surface-600 flex-shrink-0" />

      <div className="flex-shrink-0 flex items-center gap-2">
        {toolIcon && <span className="text-accent flex items-center">{toolIcon}</span>}
        <span className="font-semibold tracking-tight text-sm text-text-primary">{toolName}</span>
        <span className="badge-client-side">🔒 Client-side</span>
      </div>

      {actions && (
        <>
          <div className="w-px h-5 bg-surface-600 mx-1 flex-shrink-0" />
          <div className="flex items-center gap-1.5 flex-1 min-w-0">{actions}</div>
        </>
      )}
    </header>
  )
}
