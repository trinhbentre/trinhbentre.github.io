interface ErrorBannerProps {
  message: string
  hint?: string
  variant?: 'error' | 'warning' | 'info'
}

const variantStyles = {
  error: {
    container: 'bg-danger/10 border-danger/30 text-danger',
    icon: '✕',
  },
  warning: {
    container: 'bg-warning/10 border-warning/30 text-warning',
    icon: '⚠',
  },
  info: {
    container: 'bg-accent/10 border-accent/30 text-accent',
    icon: 'ℹ',
  },
} as const

export function ErrorBanner({ message, hint, variant = 'error' }: ErrorBannerProps) {
  const styles = variantStyles[variant]
  return (
    <div
      role="alert"
      className={['flex flex-col gap-1 px-3 py-2 rounded-md border text-xs font-mono', styles.container].join(
        ' ',
      )}
    >
      <span>
        <span className="mr-1.5" aria-hidden="true">
          {styles.icon}
        </span>
        {message}
      </span>
      {hint && <span className="text-text-secondary pl-4">{hint}</span>}
    </div>
  )
}
