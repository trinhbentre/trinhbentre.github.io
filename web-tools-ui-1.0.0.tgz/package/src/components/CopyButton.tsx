import { useCallback } from 'react'
import { useCopyToClipboard } from '../hooks/useCopyToClipboard'
import { CopyIcon } from './icons/CopyIcon'
import { Button } from './Button'

interface CopyButtonProps {
  value: string
  size?: 'sm' | 'md'
  label?: string
  disabled?: boolean
  className?: string
}

export function CopyButton({
  value,
  size = 'sm',
  label = 'Copy',
  disabled,
  className,
}: CopyButtonProps) {
  const { copied, copy } = useCopyToClipboard()

  const handleClick = useCallback(() => {
    if (value) copy(value)
  }, [value, copy])

  return (
    <Button
      variant="secondary"
      size={size}
      disabled={disabled || !value}
      onClick={handleClick}
      className={className}
      aria-label={copied ? 'Copied!' : label}
    >
      {copied ? (
        <span className="inline-flex items-center gap-1">
          <svg
            className="w-3 h-3 text-success"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
          Copied
        </span>
      ) : (
        <span className="inline-flex items-center gap-1">
          <CopyIcon className="w-3 h-3" />
          {label}
        </span>
      )}
    </Button>
  )
}
