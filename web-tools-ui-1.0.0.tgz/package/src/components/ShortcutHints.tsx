import { useCallback } from 'react'
import { useStorage } from '../hooks/useStorage'

interface ShortcutHintsProps {
  shortcuts: { keys: string; label: string }[]
  dismissable?: boolean
  storageKey?: string
}

export function ShortcutHints({
  shortcuts,
  dismissable = false,
  storageKey = 'ui-shortcut-hints-dismissed',
}: ShortcutHintsProps) {
  const [dismissed, setDismissed] = useStorage<boolean>(storageKey, false)

  const handleDismiss = useCallback(() => {
    setDismissed(true)
  }, [setDismissed])

  if (dismissable && dismissed) return null

  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 justify-center">
      {shortcuts.map(({ keys, label }) => (
        <span key={keys} className="text-xs text-text-muted font-mono">
          <kbd className="not-italic">{keys}</kbd>
          {' '}
          {label}
        </span>
      ))}
      {dismissable && (
        <button
          type="button"
          onClick={handleDismiss}
          className="text-xs text-text-muted hover:text-text-secondary transition-colors ml-2"
          aria-label="Dismiss keyboard shortcut hints"
        >
          ✕
        </button>
      )}
    </div>
  )
}

/** Detect modifier key symbol for current platform */
export function getPlatformMod(): string {
  if (typeof navigator === 'undefined') return 'Ctrl'
  return /Mac|iPhone|iPad/i.test(navigator.platform) ? '⌘' : 'Ctrl'
}

export function getPlatformShift(): string {
  if (typeof navigator === 'undefined') return 'Shift'
  return /Mac|iPhone|iPad/i.test(navigator.platform) ? '⇧' : 'Shift'
}
