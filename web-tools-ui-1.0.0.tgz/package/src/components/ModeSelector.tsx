import { useCallback } from 'react'

interface ModeSelectorOption {
  id: string
  label: string
  shortcut?: string
}

interface ModeSelectorProps {
  options: ModeSelectorOption[]
  activeId: string
  onChange: (id: string) => void
  variant?: 'pill' | 'bar'
  className?: string
  'aria-label'?: string
}

export function ModeSelector({
  options,
  activeId,
  onChange,
  variant = 'pill',
  className = '',
  'aria-label': ariaLabel,
}: ModeSelectorProps) {
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent, id: string) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault()
        onChange(id)
      }
    },
    [onChange],
  )

  if (variant === 'bar') {
    return (
      <div
        className={['flex flex-wrap gap-1 px-4 py-3 border-b border-surface-700 bg-surface-800', className].join(' ')}
        role="tablist"
        aria-label={ariaLabel}
      >
        {options.map(opt => (
          <button
            key={opt.id}
            type="button"
            role="tab"
            aria-selected={activeId === opt.id}
            onClick={() => onChange(opt.id)}
            onKeyDown={e => handleKeyDown(e, opt.id)}
            title={opt.shortcut ? `${opt.label} (${opt.shortcut})` : opt.label}
            className={[
              'px-3 py-1.5 rounded-md text-sm font-medium transition-colors duration-150',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50',
              activeId === opt.id
                ? 'bg-accent text-surface-900'
                : 'bg-surface-700 hover:bg-surface-600 text-text-secondary hover:text-text-primary border border-surface-600',
            ].join(' ')}
          >
            {opt.label}
          </button>
        ))}
      </div>
    )
  }

  // pill variant — contained in a rounded surface-900 box
  return (
    <div
      className={['inline-flex items-center gap-1 bg-surface-900 p-1 rounded-lg', className].join(' ')}
      role="tablist"
      aria-label={ariaLabel}
    >
      {options.map(opt => (
        <button
          key={opt.id}
          type="button"
          role="tab"
          aria-selected={activeId === opt.id}
          onClick={() => onChange(opt.id)}
          onKeyDown={e => handleKeyDown(e, opt.id)}
          title={opt.shortcut ? `${opt.label} (${opt.shortcut})` : opt.label}
          className={[
            'px-3 py-1 rounded-md text-sm font-medium transition-colors duration-150',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50',
            activeId === opt.id
              ? 'bg-surface-800 text-text-primary shadow-sm'
              : 'text-text-secondary hover:text-text-primary',
          ].join(' ')}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}
