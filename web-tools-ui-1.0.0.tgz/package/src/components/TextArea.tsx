import { forwardRef, useEffect, useRef, useState } from 'react'
import { formatBytes } from '../utils/formatBytes'

interface TextAreaProps extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'onChange'> {
  label?: string
  value: string
  onChange?: (value: string) => void
  error?: string
  showByteCount?: boolean
  mono?: boolean
  actions?: React.ReactNode
}

export const TextArea = forwardRef<HTMLTextAreaElement, TextAreaProps>(
  (
    {
      label,
      value,
      onChange,
      error,
      showByteCount = false,
      mono = true,
      actions,
      className = '',
      readOnly,
      ...props
    },
    ref,
  ) => {
    const [byteSize, setByteSize] = useState(0)
    const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

    useEffect(() => {
      if (!showByteCount) return
      if (timerRef.current) clearTimeout(timerRef.current)
      timerRef.current = setTimeout(() => {
        setByteSize(new Blob([value]).size)
      }, 100)
      return () => {
        if (timerRef.current) clearTimeout(timerRef.current)
      }
    }, [value, showByteCount])

    return (
      <div className="flex flex-col gap-2">
        {(label || actions) && (
          <div className="flex items-center justify-between">
            {label && <span className="label">{label}</span>}
            {actions && <div className="flex gap-2">{actions}</div>}
          </div>
        )}

        <textarea
          ref={ref}
          value={value}
          readOnly={readOnly}
          onChange={onChange ? e => onChange(e.target.value) : undefined}
          spellCheck={false}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          className={[
            'w-full h-40 bg-surface-700 border rounded-md px-3 py-2 text-sm text-text-primary placeholder-text-muted resize-y',
            'focus:outline-none focus:ring-2 focus:ring-accent/50 focus:border-accent transition-colors duration-150',
            error ? 'border-danger/60' : 'border-surface-600',
            mono ? 'font-mono' : '',
            readOnly ? 'cursor-default' : '',
            className,
          ]
            .filter(Boolean)
            .join(' ')}
          {...props}
        />

        {(error || showByteCount) && (
          <div className="flex items-center justify-between gap-2">
            {error ? (
              <span className="text-xs text-danger">{error}</span>
            ) : (
              <span />
            )}
            {showByteCount && (
              <span className="text-xs text-text-muted font-mono">
                {value.length.toLocaleString()} chars · {formatBytes(byteSize)}
              </span>
            )}
          </div>
        )}
      </div>
    )
  },
)

TextArea.displayName = 'TextArea'
