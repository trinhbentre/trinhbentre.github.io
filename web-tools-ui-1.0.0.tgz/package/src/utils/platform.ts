/** Returns true when running on macOS / iOS */
export function isMacPlatform(): boolean {
  if (typeof navigator === 'undefined') return false
  return /Mac|iPhone|iPad/i.test(navigator.platform)
}

/** Returns "⌘" on Mac, "Ctrl" elsewhere */
export function modKey(): string {
  return isMacPlatform() ? '⌘' : 'Ctrl'
}

/** Returns "⇧" on Mac, "Shift" elsewhere */
export function shiftKey(): string {
  return isMacPlatform() ? '⇧' : 'Shift'
}
