import type { Config } from 'tailwindcss'

export const webToolsPreset = {
  theme: {
    extend: {
      colors: {
        surface: {
          900: '#0d1117',
          850: '#131920',
          800: '#161b22',
          700: '#21262d',
          600: '#30363d',
        },
        accent: {
          DEFAULT: '#58a6ff',
          hover: '#79c0ff',
          muted: 'rgba(88, 166, 255, 0.15)',
        },
        success: '#3fb950',
        warning: '#d29922',
        danger: '#f85149',
        text: {
          primary: '#e6edf3',
          secondary: '#8b949e',
          muted: '#484f58',
        },
      },
      fontFamily: {
        mono: ["'JetBrains Mono'", 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      boxShadow: {
        sm: '0 1px 2px rgba(0, 0, 0, 0.3)',
        md: '0 1px 8px rgba(0, 0, 0, 0.4)',
        lg: '0 4px 16px rgba(0, 0, 0, 0.5)',
      },
    },
  },
} satisfies Partial<Config>
